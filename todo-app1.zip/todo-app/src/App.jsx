import { useState } from "react";
import "./index.css";

function App() {
  const [lists, setLists] = useState([]);
  const [listName, setListName] = useState("");
  const [taskText, setTaskText] = useState("");

  const addList = () => {
    if (!listName.trim()) return;

    setLists([
      ...lists,
      { name: listName, tasks: [] }
    ]);
    setListName("");
  };

  const addTask = (listIndex) => {
    if (!taskText.trim()) return;

    const updatedLists = [...lists];
    updatedLists[listIndex].tasks.push(taskText);

    setLists(updatedLists);
    setTaskText("");
  };

  const deleteTask = (listIndex, taskIndex) => {
    const updatedLists = [...lists];
    updatedLists[listIndex].tasks.splice(taskIndex, 1);
    setLists(updatedLists);
  };

  return (
    <div className="container">
      <h1>📝 Multiple To-Do Lists</h1>

      {/* Add new list */}
      <input
        value={listName}
        placeholder="New list name..."
        onChange={(e) => setListName(e.target.value)}
      />
      <button onClick={addList}>Add List</button>

      {/* Render lists */}
      {lists.map((list, listIndex) => (
        <div key={listIndex} className="list-box">
          <h2>{list.name}</h2>

          <input
            value={taskText}
            placeholder="New task..."
            onChange={(e) => setTaskText(e.target.value)}
          />
          <button onClick={() => addTask(listIndex)}>Add Task</button>

          <ul>
            {list.tasks.map((task, taskIndex) => (
              <li key={taskIndex}>
                {task}
                <button
                  onClick={() => deleteTask(listIndex, taskIndex)}
                >
                  ❌
                </button>
              </li>
            ))}
          </ul>
        </div>
      ))}
    </div>
  );
}

export default App;
